from django.shortcuts import render

def index(request):
    return render(request, 'main/index.html')

def dates(request):
    return render(request, 'main/dates.html')

def drink(request):
    return render(request, 'main/drink.html')
